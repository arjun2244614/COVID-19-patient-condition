#libraries needed
library(caret)
library(class)
library(corrplot)
library(dplyr)
library(e1071)
library(FNN)
library(gmodels)
library(psych)
library(ggvis)
data<-read.csv("e:/R/covid.csv",header = TRUE)
data
head(data)
#We will will be removing the columns which will not be used in our analysis. id,entry_date , date_symptoms ,contact_other_covid will be removed.
df<-data
head(df)
df$entry_date=NULL
df$date_symptoms=NULL
df$id=NULL
df$contact_other_covid=NULL

df$sex[df$sex == 2] <- 0 #Replacing the value of 2 as male to 0 as male. Now, 0-male and 1-female
head(df)
df$patient_type[df$patient_type==2]<-0 ##Replacing the value of 2 as hospitalized to 0 as hospitalized. Now, 0-hospitalized and 1-not hospitalized
colnames(df)[3]<-"died" #Changed the column name from date_died to died

#In the data, missing values or not specified values are mentioned as 97,98,99. So i am replacing all the missing values as NULL
df$intubed[df$intubed %in% c(97,98,99)]<-NA
df$pneumonia[df$pneumonia %in% c(97,98,99)]<-NA
df$pregnancy[df$pregnancy %in% c(97,98,99)]<-NA
df$diabetes[df$diabetes %in% c(97,98,99)]<-NA
df$copd[df$copd %in% c(97,98,99)]<-NA
df$asthma[df$asthma %in% c(97,98,99)]<-NA
df$inmsupr[df$inmsupr %in% c(97,98,99)]<-NA
df$hypertension[df$hypertension %in% c(97,98,99)]<-NA
df$other_disease[df$other_disease %in% c(97,98,99)]<-NA
df$cardiovascular[df$cardiovascular %in% c(97,98,99)]<-NA
df$obesity[df$obesity %in% c(97,98,99)]<-NA
df$renal_chronic[df$renal_chronic %in% c(97,98,99)]<-NA
df$tobacco[df$tobacco %in% c(97,98,99)]<-NA
df$covid_res[df$covid_res %in% c(97,98,99)]<-NA
df$icu[df$icu %in% c(97,98,99)]<-NA
df$age[df$age %in% c(0)]<-NA
df$covid_res[df$covid_res==3]<- NA # ignore all awating data


df$died=NULL
head(df) 
summary(df)


#We can observe that 80% of the null values or Not specified values are in ICU Pregnancy Columns and intubed So we will no be using these for any analysis.
df$pregnancy=NULL
df$icu=NULL
df$intubed=NULL
head(df)
summary(df)
df=na.omit(df) # removed all the NA values from dataframe
dim(data)      #original data had 566602 rows and 23 columns  
dim(df)    # Data After clening has 562647 rows and 16 columns
head(df)
summary(df)
df$pneumonia[df$pneumonia==2]<-0 #0-NO 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
df$copd[df$copd==2]<-0      #0-No 1-Yes
df$asthma[df$asthma==2]<-0   #0-No 1-Yes
df$inmsupr[df$inmsupr==2]<-0   #0-No 1-Yes
df$hypertension[df$hypertension==2]<-0   #0-No 1-Yes
df$other_disease[df$other_disease==2]<-0   #0-No 1-Yes
df$cardiovascular[df$cardiovascular==2]<-0   #0-No 1-Yes
df$obesity[df$obesity==2]<-0   #0-No 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
df$renal_chronic[df$renal_chronic==2]<-0   #0-No 1-Yes
df$tobacco[df$tobacco==2]<-0   #0-No 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
#df$covid_res : 0 - Positive, 1 - Negative
df$covid_res[df$covid_res==1]<- 0
df$covid_res[df$covid_res==2]<- 1
#Repaced the cateorical values into Binary Values
head(df)
summary(df)
str(df)
data_norm <- function(x) {
  return ((x-min(x))/(max(x)-min(x)))
}
datn<-as.data.frame(lapply(df[,1:15],data_norm))
df<-datn
Hmisc::describe(df)
# changing continous fields to factor
df[c(15)] <- lapply(df[c(15)],factor)

df[c(1:3,5:14)] <- lapply(df[c(1:3,5:14)],factor)
# histogram 
barplot(table(df$sex),main='0-Male 1- Female',xlab="Sex Count",
        col="red")
barplot(table(df$patient),las=1,main='0-Hospitalized 1.Not Hospitalized',xlab="Patient",col="red")
hist(df$age,main='Age',xlab="Age",
     col="red")
barplot(table(df$pneumonia),main='0-No 1.Yes',xlab="Pneumonia",
        col="red")
barplot(table(df$diabetes),main='0-No 1-Yes',xlab="diabetes",
        col="red")
barplot(table(df$copd),main='0-No 1-Yes',xlab="Copd",
        col="red")

barplot(table(df$inmsupr),main='0-No 1-Yes',xlab="Inmsupr",
        col="red")
barplot(table(df$hypertension),main='0-No 1-Yes',xlab="Hypertension",
        col="red")
barplot(table(df$cardiovascular),main='0-No 1-Yes',xlab="Cardio",
        col="red")
barplot(table(df$obesity),main='0-No 1-Yes',xlab="Obesity",
        col="red")
barplot(table(df$renal_chronic),main='0-No 1-Yes',xlab="RenalChronic",
        col="red")
barplot(table(df$other_disease),main='0-No 1-Yes',xlab="OtherDisease",
        col="red")
barplot(table(df$tobacco ),main='0-No 1-Yes',xlab="tobacco",
        col="red")
barplot(table(df$covid_res),main='0-Positive 1-Neagative',xlab="Covid",
        col="red")
head(df)
summary(df)
head(df)
library(Hmisc)
co <- rcorr(as.matrix(df))
co$r
library(corrplot)
corrplot(co$r, method = "square")
corrplot(co$r,order='AOE',method='color',addCoef.col='blue')
pairs(df)
library('ggplot2')
df1<-df
df<-datn
# set the seed to make the partition reproducible
set.seed(1234)
head(df)
# view correlation between features
corrMat <- cor(df)
correlated <- findCorrelation(corrMat, cutoff = 0.01)
data_y <- df %>% select(covid_res)
data_x <- df %>% select(-covid_res)
# 75% of the sample size
smp_size <- floor(0.75 * nrow(data_x))
train_ind <- sample(seq_len(nrow(data_x)), size = smp_size)
# creating test and training sets that contain all of the predictors
train.X <- data_x[train_ind, ]
train.Y <- data_y[train_ind, ]

test.X <- data_x[-train_ind, ]
test.Y <- data_y[-train_ind, ]

# sqrt (370724) =~ 608/609 : we have 370724 training examples
pred_knn.608 <- knn(train = train.X, test = test.X, cl = train.Y, k=608)
pred_knn.609 <- knn(train = train.X, test = test.X, cl = train.Y, k=609)

accuracy <- function(x){sum(diag(x)/(sum(rowSums(x)))) * 100}

tab.608 <- table(pred_knn.608,test.Y)
accuracy(tab.608)
confusionMatrix(tab.608)

tab.609 <- table(pred_knn.609,test.Y)
accuracy(tab.609)
confusionMatrix(tab.609)

# Find optimal value of K and plot the results
i=1
k.optm=1
while (i <= 611){
  knn.mod <- knn(train = train.X, test = test.X, cl = train.Y, k=i)
  knn.res <- table(knn.mod,test.Y)
  k.optm[i] <- accuracy(knn.res)
  cat('k[', i, ']', '=', k.optm[i],'\n')
  i = i+10
}
plot(k.optm, type="b", xlab="K- Value",ylab="Accuracy level")


#Logistic Regression-----------------------

ran <- sample(1:nrow(df), 0.5 * nrow(df))

train1 <- df[c(1:15)][ran,]
test1 <- df[c(1:15)][-ran,]

glm.fits=glm(covid_res ~ ., data = train1 ,family = binomial )
summary (glm.fits)


fitted.results <- predict(glm.fits, newdata=subset(train1,select=c(1:14)),type='response')
fitted.results <- ifelse(fitted.results > 0.5,1,0)
ClasificError <- mean(fitted.results == train1$covid_res)
print(paste('Accuracy', ClasificError))

fitted.results <- predict(glm.fits, newdata=subset(test1,select=c(1:14)),type='response')
fitted.results <- ifelse(fitted.results > 0.5,1,0)
ClasificError <- mean(fitted.results == test1$covid_res)
print(paste('Accuracy', ClasificError))
anova(glm.fits , test = "Chisq")
fitted.results


#Naive Bayes----------------------------------
library(e1071)
head(datn)
str(df1)
#spliting the data into train and test
ran <- sample(1:nrow(df), 0.7 * nrow(df1))

train1 <- df1[c(1:15)][ran,]
nrow(train1)# no of rows for training data
test1 <- df1[c(1:15)][-ran,]
nrow(test1)#no of rows for test data

Clas<- naiveBayes( train1$covid_res~ sex + patient_type + pneumonia + diabetes + copd + asthma, data=train1)
Clas #conditional probablity for each attributes
predict_y <- predict(Clas,test1) # prediction on test data
confusionMatrix(table(predict_y,test1$covid_res)) # confustionMatrix for the accuracy.

