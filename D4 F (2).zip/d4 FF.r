#libraries needed
library(caret)
library(class)
library(corrplot)
library(dplyr)
library(e1071)
library(FNN)
library(gmodels)
library(psych)
library(ggvis)

data<-read.csv("e:/R/covid.csv",header = TRUE) #read the file
data
head(data)
#We will will be removing the columns which will not be used in our analysis. id,entry_date , date_symptoms ,contact_other_covid will be removed.
df<-data
head(df)
df$entry_date=NULL
df$date_symptoms=NULL
df$id=NULL
df$contact_other_covid=NULL

df$sex[df$sex == 2] <- 0 #Replacing the value of 2 as male to 0 as male. Now, 0-male and 1-female
head(df)
df$patient_type[df$patient_type==2]<-0 ##Replacing the value of 2 as hospitalized to 0 as hospitalized. Now, 0-hospitalized and 1-not hospitalized
colnames(df)[3]<-"died" #Changed the column name from date_died to died

#In the data, missing values or not specified values are mentioned as 97,98,99. So i am replacing all the missing values as NULL
df$intubed[df$intubed %in% c(97,98,99)]<-NA
df$pneumonia[df$pneumonia %in% c(97,98,99)]<-NA
df$pregnancy[df$pregnancy %in% c(97,98,99)]<-NA
df$diabetes[df$diabetes %in% c(97,98,99)]<-NA
df$copd[df$copd %in% c(97,98,99)]<-NA
df$asthma[df$asthma %in% c(97,98,99)]<-NA
df$inmsupr[df$inmsupr %in% c(97,98,99)]<-NA
df$hypertension[df$hypertension %in% c(97,98,99)]<-NA
df$other_disease[df$other_disease %in% c(97,98,99)]<-NA
df$cardiovascular[df$cardiovascular %in% c(97,98,99)]<-NA
df$obesity[df$obesity %in% c(97,98,99)]<-NA
df$renal_chronic[df$renal_chronic %in% c(97,98,99)]<-NA
df$tobacco[df$tobacco %in% c(97,98,99)]<-NA
df$covid_res[df$covid_res %in% c(97,98,99)]<-NA
df$icu[df$icu %in% c(97,98,99)]<-NA
df$age[df$age %in% c(0)]<-NA
df$covid_res[df$covid_res==3]<- NA # ignore all awating data


df$died=NULL # Removed died column as this is not required for our analysis
head(df) 
summary(df)


#From summary We can observe that 80% of the null values or Not specified values are in ICU Pregnancy Columns and intubed So we will no be using these for any analysis.
df$pregnancy=NULL
df$icu=NULL
df$intubed=NULL
head(df)
summary(df)
df=na.omit(df) # removed all the NA values from dataframe
dim(data)      #original data had 566602 rows and 23 columns  
dim(df)    # Data After clening has 562647 rows and 16 columns
head(df)
summary(df)
#Repaced the cateorical values into Binary Values
df$pneumonia[df$pneumonia==2]<-0 #0-NO 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
df$copd[df$copd==2]<-0      #0-No 1-Yes
df$asthma[df$asthma==2]<-0   #0-No 1-Yes
df$inmsupr[df$inmsupr==2]<-0   #0-No 1-Yes
df$hypertension[df$hypertension==2]<-0   #0-No 1-Yes
df$other_disease[df$other_disease==2]<-0   #0-No 1-Yes
df$cardiovascular[df$cardiovascular==2]<-0   #0-No 1-Yes
df$obesity[df$obesity==2]<-0   #0-No 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
df$renal_chronic[df$renal_chronic==2]<-0   #0-No 1-Yes
df$tobacco[df$tobacco==2]<-0   #0-No 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
#df$covid_res : 0 - Positive, 1 - Negative
df$covid_res[df$covid_res==1]<- 0
df$covid_res[df$covid_res==2]<- 1

head(df)
summary(df)
str(df)
#data normalization in the scale of -1 to 1
data_norm <- function(x) {
  return ((x-min(x))/(max(x)-min(x)))
}
datn<-as.data.frame(lapply(df[,1:15],data_norm))
df<-datn
Hmisc::describe(df)
# changing continous fields to factor
df[c(15)] <- lapply(df[c(15)],factor)

df[c(1:3,5:14)] <- lapply(df[c(1:3,5:14)],factor)
# histogram 
barplot(table(df$sex),main='0-Male 1- Female',xlab="Sex Count",
        col="red")
barplot(table(df$patient),las=1,main='0-Hospitalized 1.Not Hospitalized',xlab="Patient",col="red")
hist(df$age,main='Age',xlab="Age",
     col="red")
barplot(table(df$pneumonia),main='0-No 1.Yes',xlab="Pneumonia",
        col="red")
barplot(table(df$diabetes),main='0-No 1-Yes',xlab="diabetes",
        col="red")
barplot(table(df$copd),main='0-No 1-Yes',xlab="Copd",
        col="red")

barplot(table(df$inmsupr),main='0-No 1-Yes',xlab="Inmsupr",
        col="red")
barplot(table(df$hypertension),main='0-No 1-Yes',xlab="Hypertension",
        col="red")
barplot(table(df$cardiovascular),main='0-No 1-Yes',xlab="Cardio",
        col="red")
barplot(table(df$obesity),main='0-No 1-Yes',xlab="Obesity",
        col="red")
barplot(table(df$renal_chronic),main='0-No 1-Yes',xlab="RenalChronic",
        col="red")
barplot(table(df$other_disease),main='0-No 1-Yes',xlab="OtherDisease",
        col="red")
barplot(table(df$tobacco ),main='0-No 1-Yes',xlab="tobacco",
        col="red")
barplot(table(df$covid_res),main='0-Positive 1-Neagative',xlab="Covid",
        col="red")
head(df)
summary(df)
head(df)
library(Hmisc)
co <- rcorr(as.matrix(df))
co$r  #correlation Matrix
library(corrplot) 
corrplot(co$r, method = "square")#correlation Plot
corrplot(co$r,order='AOE',method='color',addCoef.col='blue') #correlation plot with coefficient values
library('ggplot2')
df1<-df
df<-datn 
# set the seed to make the partition reproducible
set.seed(1234)
head(df)
# view correlation between features
corrMat <- cor(df)
correlated <- findCorrelation(corrMat, cutoff = 0.01)
data_y <- df %>% select(covid_res) # storing response variable covid_res in data_y
data_x <- df %>% select(-covid_res) # storing all the predictors varibale in data_x
# 75% of the sample size
smp_size <- floor(0.75 * nrow(data_x))
train_ind <- sample(seq_len(nrow(data_x)), size = smp_size)
# creating test and training sets that contain all of the predictors
train.X <- data_x[train_ind, ]
train.Y <- data_y[train_ind, ]

test.X <- data_x[-train_ind, ]
test.Y <- data_y[-train_ind, ]
#KNN---------------------------------------
# sqrt (370724) =~ 608/609 : we have 370724 training examples
pred_knn.608 <- knn(train = train.X, test = test.X, cl = train.Y, k=608)
pred_knn.609 <- knn(train = train.X, test = test.X, cl = train.Y, k=609)

accuracy <- function(x){sum(diag(x)/(sum(rowSums(x)))) * 100}

tab.608 <- table(pred_knn.608,test.Y)
accuracy(tab.608)
confusionMatrix(tab.608)

tab.609 <- table(pred_knn.609,test.Y)
accuracy(tab.609)
confusionMatrix(tab.609)

# Find optimal value of K and plot the results
i=1
k.optm=1
while (i <= 611){
  knn.mod <- knn(train = train.X, test = test.X, cl = train.Y, k=i)
  knn.res <- table(knn.mod,test.Y)
  k.optm[i] <- accuracy(knn.res)
  cat('k[', i, ']', '=', k.optm[i],'\n')
  i = i+10
}
plot(k.optm, type="b", xlab="K- Value",ylab="Accuracy level")


#Logistic Regression-----------------------

ran <- sample(1:nrow(df), 0.5 * nrow(df))

train1 <- df[c(1:15)][ran,]
test1 <- df[c(1:15)][-ran,]

glm.fits=glm(covid_res ~ ., data = train1 ,family = binomial )
summary (glm.fits)


fitted.results <- predict(glm.fits, newdata=subset(train1,select=c(1:14)),type='response')
fitted.results <- ifelse(fitted.results > 0.5,1,0)
ClasificError <- mean(fitted.results == train1$covid_res)
print(paste('Accuracy', ClasificError))

fitted.results <- predict(glm.fits, newdata=subset(test1,select=c(1:14)),type='response')
fitted.results <- ifelse(fitted.results > 0.5,1,0)
ClasificError <- mean(fitted.results == test1$covid_res)
print(paste('Accuracy', ClasificError))
anova(glm.fits , test = "Chisq")
fitted.results


#Naive Bayes----------------------------------
#A Naive Bayes classifier is a probabilistic machine learning model that's used for classification task.
library(e1071) #navie bayes library
head(datn)
#spliting the data into train and test
ran <- sample(1:nrow(df1), 0.7 * nrow(df1)) 

train1 <- df1[c(1:15)][ran,] #
nrow(train1)# no of rows for training data
test1 <- df1[c(1:15)][-ran,]
nrow(test1)#no of rows for test data

Clas<- naiveBayes( train1$covid_res~ sex + patient_type + pneumonia + diabetes + copd + asthma, data=train1) #Training the model to predict covid result with predictors sex,patient type,pneumonia,diabetes ,copd,asthma.
Clas #conditional probablity for each attributes
predict_y <- predict(Clas,test1) # prediction on test data
confusionMatrix(table(predict_y,test1$covid_res)) # confustionMatrix for the accuracy.
#--------------

#1. Model Assessment: By increasing the flexibility of your models gradually, you will assess the predictive performance by using
#a. the entire data set as the training data.
head(datn)
#spliting the data into train and test
ran <- sample(1:nrow(df1), 1 * nrow(df1))
train1 <- df1[c(1:15)][ran,] #
nrow(train1)# no of rows for training data
Clas<- naiveBayes( train1$covid_res~ sex + patient_type + pneumonia + diabetes , data=train1) #Training the model to predict covid result with predictors sex,patient type,pneumonia,diabetes ,copd,asthma.
Clas #conditional probablity for each attributes
predict_y <- predict(Clas,train1) # prediction on test data
confusionMatrix(table(predict_y,train1$covid_res)) # confustionMatrix for the accuracy.

#-------------------
Clas<- naiveBayes( train1$covid_res~ sex + patient_type + pneumonia + diabetes+tobacco+renal_chronic , data=train1) #Training the model to predict covid result with predictors sex,patient type,pneumonia,diabetes ,copd,asthma.
Clas #conditional probablity for each attributes
predict_y <- predict(Clas,train1) # prediction on test data
confusionMatrix(table(predict_y,train1$covid_res)) # confustionMatrix for the accuracy.
#------------------------
#spliting the data into train and test
set.seed(101) # Set Seed so that same sample can be reproduced in future also
ran <- sample(1:nrow(df1), .1 * nrow(df1))
train1 <- df1[c(1:15)][ran,] #
library(caret)

# Define train control for k fold cross validation
train_control <- trainControl(method="cv", number=10)
# Fit Naive Bayes Model
model <- train(covid_res~., data=train1, trControl=train_control, method="nb")
# Summarise Results
print(model)
plot(model)

#----------------

# load the library
library(caret)
# define training control
train_control <- trainControl(method="LOOCV")
# train the model
model11 <- train(covid_res~., data=train1, trControl=train_control, method="nb")
         # summarize results
print(model11)
plot(model)

#----------------------
#Logistic Regression
#---------logistic regression with -whole dataset approch  ----------------------------
i=1
acc= list()
while (i <= 10){
  lr.mod <- glm(covid_res~ poly(age, i)+sex+patient_type+pneumonia+diabetes+
                  copd+asthma+inmsupr+hypertension+other_disease+cardiovascular+obesity+renal_chronic+tobacco ,
                data = df ,family =binomial )
  print(summary(lr.mod))
  fitted.results <- predict(lr.mod, newdata=subset(df,select=c(1:14)),type='response')
  fitted.results <- ifelse(fitted.results > 0.5,1,0)
  ClasificError <- mean(fitted.results == df$covid_res)
  print(ClasificError)
  acc[[i]] <- ClasificError
  i = i+1
}
acc
plot(unlist(acc))                

#---------------------------------------------------------------------------------
#---------logistic regression with - validation set approch ----------------------------

ran <- sample(1:nrow(df), 0.5 * nrow(df))

train1 <- df[c(1:15)][ran,]
test1 <- df[c(1:15)][-ran,]

i=1
acc= list()
while (i <= 10){
  lr.mod <- glm(covid_res~ poly(age, i)+sex+patient_type+pneumonia+diabetes+
                  copd+asthma+inmsupr+hypertension+other_disease+cardiovascular+obesity+renal_chronic+tobacco ,
                data = train1 ,family =binomial )
  print(summary(lr.mod))
  fitted.results <- predict(lr.mod, newdata=subset(test1,select=c(1:14)),type='response')
  fitted.results <- ifelse(fitted.results > 0.5,1,0)
  ClasificError <- mean(fitted.results == test1$covid_res)
  print(ClasificError)
  acc[[i]] <- ClasificError
  i = i+1
}
acc
plot(unlist(acc)) 

#---------------------------------------------------------------------------------------------- 
#----------------------------------------------------------------------------------
#---------logistic regression with - k- fold----------------------------

i=1
acc= list()
while (i <= 10){
  lr.mod <-glm(covid_res~ poly(age, i)+sex+patient_type+pneumonia+diabetes+
                 copd+asthma+inmsupr+hypertension+other_disease+cardiovascular+obesity+renal_chronic+tobacco ,
               data = df ,family =binomial )
  cv.err =cv.glm(df ,lr.mod , K = 10 )
  print(cv.err$delta[1])
  acc[[i]] <- 1- cv.err$delta[1]
  i = i+1
}

acc
plot(unlist(acc))

#KNN---------------------------------------
# LOOCV
pred_knn.5 <- knn(train = train.X, test = test.X, cl = train.Y, k=5)
pred_knn.10 <- knn(train = train.X, test = test.X, cl = train.Y, k=10)

accuracy <- function(x){sum(diag(x)/(sum(rowSums(x)))) * 100}

tab.5 <- table(pred_knn.5,test.Y)
accuracy(tab.5)
confusionMatrix(tab.5)
plot(tab.5)

tab.10 <- table(pred_knn.10,test.Y)
accuracy(tab.10)
confusionMatrix(tab.10)
plot(tab.10)

#Cross Validation , with 5 fold
i=5
k.optm=1
while (i <= 10){
  knn.mod <- knn(train = train.X, test = test.X, cl = train.Y, k=i)
  knn.res <- table(knn.mod,test.Y)
  k.optm[i] <- accuracy(knn.res)
  cat('k[', i, ']', '=', k.optm[i],'\n')
  i = i+5
}
#plotting cross-validated prediction accuracy 
plot(k.optm,type = "b", xlab="K- Value",ylab="Accuracy level")

#Cross Validation, with 10 fold to create a 10-fold cross-validation based search of k, repeated 3 times
i=5
knn_results.k=1
knn_results.Accuracy=1
while (i <= 50){
  knn.mod <- knn(train = train.X, test = test.X, cl = train.Y, k=i)
  knn.res <- table(knn.mod,test.Y)
  
  knn_results.k[i] <- i
  knn_results.Accuracy[i] <- accuracy(knn.res)
  
  cat('k[', i, ']', '=',  knn_results.Accuracy[i], '\n')
  i = i+5
}

#plotting cross-validated prediction accuracy 
qplot(knn_results.k, knn_results.Accuracy,geom = "line",
      xlab = "k", ylab = "Accuracy")


#######
input.data <-df[sample(nrow(df), 20000), ]

smp_size <- floor(0.25 * nrow(input.data ))
train_ind <- sample(seq_len(nrow(input.data)), size = smp_size)

input.data.train <- df[train_ind, ]
input.data.test <- df[-train_ind, ]

#To create a 10-fold cross-validation based search of k, repeated 3 times we have to use the function trainControl:
trCtrl.knn <- trainControl(method = "repeatedcv", 
                           number = 10,  #10-fold CV
                           repeats = 3,
                           classProbs = TRUE,
                           savePredictions = TRUE)
model.knn <- train(covid_res ~ ., 
                   data=input.data.train, 
                   method="knn",
                   trControl = trCtrl.knn,
                   preProcess = c("center","scale"),
                   tuneLength=10)

model.knn_predict <- predict(model.knn, newdata = input.data.test)

print(model.knn)

plot(model.knn)

#Bootstap Naive Bayes
#Bootstap
train_control <- trainControl(method="boot", number=10)
# train the model
model1 <- train(covid_res~sex + patient_type + pneumonia, data=train1, trControl=train_control, method="nb")
# summarize results
print(model1)
plot(model1)


