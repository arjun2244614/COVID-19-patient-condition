data<-read.csv("e:/R/covid.csv",header = TRUE)
data
head(data)
#We will will be removing the columns which will not be used in our analysis. id,entry_date , date_symptoms ,contact_other_covid will be removed.
df<-data
head(df)
df$entry_date=NULL
df$date_symptoms=NULL
df$id=NULL
df$contact_other_covid=NULL

df$sex[df$sex == 2] <- 0 #Replacing the value of 2 as male to 0 as male. Now, 0-male and 1-female
head(df)
df$patient_type[df$patient_type==2]<-0 ##Replacing the value of 2 as hospitalized to 0 as hospitalized. Now, 0-hospitalized and 1-not hospitalized
colnames(df)[3]<-"died" #Changed the column name from date_died to died

#In the data, missing values or not specified values are mentioned as 97,98,99. So i am replacing all the missing values as NULL
df$intubed[df$intubed %in% c(97,98,99)]<-NA
df$pneumonia[df$pneumonia %in% c(97,98,99)]<-NA
df$pregnancy[df$pregnancy %in% c(97,98,99)]<-NA
df$diabetes[df$diabetes %in% c(97,98,99)]<-NA
df$copd[df$copd %in% c(97,98,99)]<-NA
df$asthma[df$asthma %in% c(97,98,99)]<-NA
df$inmsupr[df$inmsupr %in% c(97,98,99)]<-NA
df$hypertension[df$hypertension %in% c(97,98,99)]<-NA
df$other_disease[df$other_disease %in% c(97,98,99)]<-NA
df$cardiovascular[df$cardiovascular %in% c(97,98,99)]<-NA
df$obesity[df$obesity %in% c(97,98,99)]<-NA
df$renal_chronic[df$renal_chronic %in% c(97,98,99)]<-NA
df$tobacco[df$tobacco %in% c(97,98,99)]<-NA
df$covid_res[df$covid_res %in% c(97,98,99)]<-NA
df$icu[df$icu %in% c(97,98,99)]<-NA


df$died=NULL
head(df) 
summary(df)


#We can observe that 80% of the null values or Not specified values are in ICU Pregnancy Columns and intubed So we will no be using these for any analysis.
df$pregnancy=NULL
df$icu=NULL
df$intubed=NULL
head(df)
summary(df)
df=na.omit(df) # removed all the NA values from dataframe
dim(data)      #original data had 566602 rows and 23 columns  
dim(df)    # Data After clening has 562647 rows and 16 columns
head(df)
summary(df)
df$pneumonia[df$pneumonia==2]<-0 #0-NO 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
df$copd[df$copd==2]<-0      #0-No 1-Yes
df$asthma[df$asthma==2]<-0   #0-No 1-Yes
df$inmsupr[df$inmsupr==2]<-0   #0-No 1-Yes
df$hypertension[df$hypertension==2]<-0   #0-No 1-Yes
df$other_disease[df$other_disease==2]<-0   #0-No 1-Yes
df$cardiovascular[df$cardiovascular==2]<-0   #0-No 1-Yes
df$obesity[df$obesity==2]<-0   #0-No 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
df$renal_chronic[df$renal_chronic==2]<-0   #0-No 1-Yes
df$tobacco[df$tobacco==2]<-0   #0-No 1-Yes
df$diabetes[df$diabetes==2]<-0   #0-No 1-Yes
#Repaced the cateorical values into Binary Values
head(df)
summary(df)

Hmisc::describe(df)
# changing continous fields to factors
df[c(15)] <- lapply(df[c(15)],factor)

df[c(1:3,5:14)] <- lapply(df[c(1:2,5:14)],factor)
# histogram 
barplot(table(df$sex),main='0-Male 1- Female',xlab="Sex Count",
        col="red")
barplot(table(df$patient),las=1,main='0-Hospitalized 1.Not Hospitalized',xlab="Patient",col="red")
hist(df$age,main='Age',xlab="Age",
     col="red")
barplot(table(df$pneumonia),main='0-No 1.Yes',xlab="Pneumonia",
        col="red")
barplot(table(df$diabetes),main='0-No 1-Yes',xlab="diabetes",
        col="red")
barplot(table(df$copd),main='0-No 1-Yes',xlab="Copd",
        col="red")

barplot(table(df$inmsupr),main='0-No 1-Yes',xlab="Inmsupr",
        col="red")
barplot(table(df$hypertension),main='0-No 1-Yes',xlab="Hypertension",
        col="red")
barplot(table(df$cardiovascular),main='0-No 1-Yes',xlab="Cardio",
        col="red")
barplot(table(df$obesity),main='0-No 1-Yes',xlab="Obesity",
        col="red")
barplot(table(df$renal_chronic),main='0-No 1-Yes',xlab="RenalChronic",
        col="red")
barplot(table(df$other_disease),main='0-No 1-Yes',xlab="OtherDisease",
        col="red")
barplot(table(df$tobacco ),main='0-No 1-Yes',xlab="tobacco",
        col="red")
barplot(table(df$covid_res),main='1-Positive 2-Neagative 3-Awating Result',xlab="Covid",
        col="red")
head(df)
summary(df)
desc($hypertension)




